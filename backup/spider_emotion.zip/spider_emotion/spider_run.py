# coding:utf-8
import time, datetime, os, traceback
from threading import Thread
from multiprocessing.pool import Pool
import requests
from lxml import etree  # 注意该模块的版本号及不同的使用方式
from ez_utils import fls_log, allot_list, err_check

'''
[state]爬取指定类别图片
#进程中添加线程综合爬取
'''

flog = fls_log(handler_name="emotion")

# ----数量只是用来做测试/ 实际数量根据任务需求再做更改
# 进程数
PCNT = 2
# 线程数
TCNT = 6

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/74.0.3729.108 Safari/537.36 '
}

# 标签为'蘑菇头'的表情包存放目录
SAVE_PATH = './download/mogutou'
# '蘑菇头'表情包链接地址
url_base = 'https://fabiaoqing.com/tag/detail/id/2/page/%s.html'
# 爬取页数的设置
URL_LIST = [url_base % i for i in range(1, 2)]  # 1 page


def save_img(img_url, path, name):
    """
        下载并保存图片
    """
    try:
        if not os.path.exists(path):
            os.makedirs(path)
        if not os.path.exists(os.path.join(path, name)):  # 对所下载图片做去重判断 +--
            with open(os.path.join(path, name), 'wb') as f:
                f.write(requests.get(img_url, headers=HEADERS, timeout=(5, 10)).content)  # 写入二进制
    except Exception as e:
        print('Exception->', e)
        traceback.print_exc()
        # 拓展完善error日志记录
        flog.log_info(">>>save-error:" + img_url)


def doWork(par1: str, par2: str = 'par2', par3: str = 'par3'):
    """
        爬取操作主入口
        :param par1: 待爬url
        :param par2: 备用参数
        :param par3: 备用参数
        :return:
    """
    # 识别并创建保存图片的目录
    # current_folder = os.getcwd()
    # if not os.path.exists('download'):
    #     os.mkdir('download')
    # t_f = os.path.join(current_folder, 'download/mogutou')
    # if not os.path.isdir(t_f):
    #     os.mkdir(t_f)
    
    flog.log_info("work>>>\t" + par1)
    try:
        resp = requests.get(par1, headers=HEADERS, timeout=(5, 10))
        # 注意该模块版本号及其使用方式
        html = etree.HTML(resp.content.decode('utf-8'))
        imgs = html.xpath('//div[@class="tagbqppdiv"]/a/img')  # list
        for r in imgs:
            img_url = r.xpath('@data-original')[0]  # pic url
            img_title = r.xpath('@title')[0].strip()  # pic desc
            file_name = img_title.split(' ')[0]  # 若无匹配则返回原内容
            if '-' in img_title:
                file_name = img_title.split('-')[0]
            if '_' in img_title:
                file_name = img_title.split('_')[0]
            save_img(img_url, SAVE_PATH, file_name + '.' + img_url.split('.')[-1])
            
    except Exception as e:
        print('Exception->', e)
        traceback.print_exc()
        flog.log_info(">>>error:" + par1)


def run_multithread(id: str, workPars: list, threadsCnt: int):
    """
        进线程综合执行函数: 进程函数中添加线程
        :param id: 1 ->for count
        :param workPars: [1]
        :param threadsCnt: 6
    """
    # flog.log_info('当前进程任务:' + id + (" ".join(str(i) for i in workPars)))
    begin = 0
    # start = time.time()
    while True:
        _threads = []  # 子线程列表
        urls = workPars[begin: begin+threadsCnt]  # [0:6] ->needless ->urls=workPars
        if not urls:
            break
        for i in urls:
            t = Thread(target=doWork, args=(i,))
            _threads.append(t)
        for t in _threads:
            t.setDaemon(True)  # 设置为守护线程/ 主程序执行完成子程序随即退出
            t.start()
        # for t in _threads:
        #     t.join()  # 与t.setDaemon(True)冲突/ 两处设置作用相反 +--
        begin += threadsCnt
    # end = time.time()
    # flog.log_info(id + '当前进程耗时:%.2fs' % (end-start))


@err_check  # 装饰器
def mixed_process_thread_crawler(processorsCnt: int, threadsCnt: int):  # java式的变量类型设置
    """
        :param processorsCnt: 进程数=2
        :param threadsCnt: 线程数=6
        :return:
    """
    pool = Pool(processorsCnt)  # 进程池
    workPars = URL_LIST  # [1]/ 待爬url列表,此处为链接最后的页码/ 缩减形式
    url_groups = allot_list(workPars, processorsCnt)  # [[1]]->处理之后的图片url list
    flog.log_info("总任务组数:" + str(len(url_groups)))
    cnt = 0  # 用于计数
    for per in url_groups:
        cnt += 1
        pool.apply_async(run_multithread, args=(str(cnt), per, threadsCnt))  # 异步非阻塞
    pool.close()
    pool.join()


if __name__ == '__main__':
    # 01-带时间戳的日志记录
    flog.log_info("START>>>" + datetime.datetime.now().strftime('%Y/%m/%d-%H:%M:%S'))
    # 02-直接显示在终端的运行耗时
    start = time.time()
    mixed_process_thread_crawler(PCNT, TCNT)  # 2/ 6
    flog.log_info("END>>>" + datetime.datetime.now().strftime('%Y/%m/%d-%H:%M:%S'))
    end = time.time()
    print('>>>程序运行总耗时:%.2fs' % (end - start))