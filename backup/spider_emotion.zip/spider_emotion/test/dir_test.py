# coding=utf-8

import os

current_folder = os.getcwd()
if not os.path.exists('download'):
    os.mkdir('download')
t_f = os.path.join(current_folder, 'download/mogutou')
if not os.path.isdir(t_f):
    os.mkdir(t_f)